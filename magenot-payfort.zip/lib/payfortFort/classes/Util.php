<?php

class Payfort_Fort_Util
{

    public static function getRegistry()
    {
        return null;
    }

}

?>