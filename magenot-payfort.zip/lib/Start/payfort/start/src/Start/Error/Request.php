<?php
class Start_Error_Request extends Start_Error
{
  public static $TYPE = "request";
}
