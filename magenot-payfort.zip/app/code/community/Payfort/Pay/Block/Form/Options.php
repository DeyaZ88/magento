<?php

class Payfort_Pay_Block_Form_Options extends Mage_Payment_Block_Form {
    protected function _construct()
    {
        parent::_construct();
        //$this->setTemplate('payfort/form/options.phtml');
    }
}